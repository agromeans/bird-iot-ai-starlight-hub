from flask import Flask, request, jsonify
import requests
import config
import argparse
import lib.opt as opt
import lib.utils as utils
from lib.engine import AiEngine, HealthEngine, NDWIEngine
from lib.logger_opt import logger
from lib.exception_opt import ExceptionCommon
import func_timeout
import os, time

app = Flask(__name__)
requests.packages.urllib3.disable_warnings()

def run_ai_and_health_engine():
    ai_engine = AiEngine()
    try:
        weights, now_time_str, save_flag = ai_engine.simulate()
    except func_timeout.exceptions.FunctionTimedOut:
        # raise ExceptionCommon(message='The recognition time is too long, stop the operation.')
        logger.error('The recognition time is too long, reboot the machine...', exc_info=True)
        os.system('echo b > /sysrq')
        
    ai_record = utils.ai_record_formatting(weights, now_time_str)
    
    if config.device_dual_starlight and config.param_enable_thermal:
        health_engine = HealthEngine()
        _, ai_objects, _, ground_temp_info = health_engine.simulate(now_time_str, save_flag)
        ai_record = utils.ai_and_health_record_formating(ai_record, ai_objects, ground_temp_info)
        
    return ai_record, now_time_str
    
@app.before_request
def before_request():
    logger.info("'{path}' start serving remote ip: {ip}".format(path=request.path, ip=request.remote_addr))

@app.route("/capture", methods=['GET'])
def capture():
    now_time_str = utils.get_UTC_time_str()
    last_capture_time_str = config.param_last_capture_time 
    
    if utils.X_minus_1_min_later(now_time_str, last_capture_time_str, config.param_capture_interval):
        ai_record, now_time_str = run_ai_and_health_engine()
        # ndwi_engine = NDWIEngine()
        # humidity = ndwi_engine.simulate(now_time_str)
        # ai_record['ndwi'] = humidity
        config.update_last_capture_time_and_write_to_file(now_time_str)
        utils.http_post_request(config.api_upload_record, ai_record)
    else:
        logger.info(f'Skip capture. Time interval <= {config.param_capture_interval} minutes.')
        
    respond = dict(status_code=200, message='')
    return respond, 200
    
@app.route("/detect/depth", methods=['GET'])
def horizontal_test():
    now_time_str = utils.get_UTC_time_str()
    save_image = request.args.get('save_image')
    
    try:
        center_depth, horizontal, weights = opt.horizontal_test(now_time_str, save_image)
    except func_timeout.exceptions.FunctionTimedOut:
        raise ExceptionCommon(message='The recognition time is too long, stop the operation.')
    except Exception as e:
        raise ExceptionCommon(message='error in horizontal_test func' + str(e))
        
    if save_image:
        ai_record = utils.ai_record_formatting(weights, now_time_str)
        if config.device_dual_starlight and config.param_enable_thermal:
            health_engine = HealthEngine()
            _, ai_objects, _, ground_temp_info = health_engine.simulate(now_time_str, save_flag=True)
            ai_record = utils.ai_and_health_record_formating(ai_record, ai_objects, ground_temp_info)
            
        utils.http_post_request(config.api_upload_record, ai_record)
        
    message = {
        "center": center_depth,
        "horizontal": horizontal
        }
        
    respond = dict(status_code=200, message=message)
    return jsonify(respond), 200
    
@app.route("/version")
def get_version():
    return config.version
    
@app.errorhandler(ExceptionCommon)
def handle_invalid_usage(error):
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response
    
@app.errorhandler(404)
def page_not_found(error):
    response = dict(status_code=404, message="404 Not Found")
    return jsonify(response), 404
    
@app.errorhandler(500)
def handle_500(error):
    response = dict(status_code=500, message="500 Error")
    return jsonify(response), 500
    
if __name__ == "__main__":
    config.reload_config()
    
    parse = argparse.ArgumentParser()
    parse.add_argument('-v', '--version', action='version', version=config.get_version(), help='Display version')
    parse.parse_args()
    
    logger.info('====The program is starting====')
    app.run(host='0.0.0.0', port=5080, threaded=False)
    