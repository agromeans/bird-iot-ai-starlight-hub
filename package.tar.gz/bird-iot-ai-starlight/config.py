from configparser import ConfigParser
from lib.logger_opt import *
import os

def write_share_config_last_capture_time(config, last_capture_time):
    config.read(share_config_file,encoding='UTF-8')
    config['param']['last_capture_time'] = last_capture_time
    with open(share_config_file, 'w') as config_file:
        config.write(config_file)

def write_share_config_last_save_image_time(config, last_save_image_time):
    config.read(share_config_file,encoding='UTF-8')
    config['param']['last_save_image_time'] = last_save_image_time
    with open(share_config_file, 'w') as config_file:
        config.write(config_file)

def init_share_config():
    init_time = '2000-01-01-00-00-00'

    share_config = ConfigParser()
    if not os.path.isfile(share_config_file):
        share_config['param'] = {
            'last_capture_time': init_time,
            'last_save_image_time': init_time
        }
    else:
        share_config.read(share_config_file)

        if not share_config.has_section('param'):
            share_config.add_section('param')

        if not share_config.has_option('param', 'last_capture_time'):
            share_config.set('param', 'last_capture_time', init_time)

        if not share_config.has_option('param', 'last_save_image_time'):
            share_config.set('param', 'last_save_image_time', init_time)

    with open(share_config_file, 'w') as config_file:
        share_config.write(config_file)

    return share_config 

config_file = './config.ini'
share_config_file = './share/config.ini'

config = ConfigParser()
config.read(config_file)

share_config = init_share_config()

version = ''

path_yolo_model_cfg = ''
path_yolo_model_weights = ''
path_yolo_model_names = ''

path_weigher_model_ckpt = ''
path_bird_weight_model = ''
path_fish_stereo_cal = ''

path_save_ai_dir = ''
path_save_raw_dir = ''
path_save_depth_dir = ''
path_save_heatmap_dir = ''
path_save_weigher_dir = ''
path_save_flir_rgb_dir = '' 
path_save_flir_raw_dir = '' 
path_save_raw_modified_dir = '' 
path_save_raw_left_dir = ''
path_save_raw_right_dir = ''
path_save_ndwi_dir = ''
path_iml_crop_param = ''

api_upload_record = ''


device_dual_rgb = None
device_dual_ir = None
device_dual_starlight = None
device_webcam = None

param_yolo_conf_thresh = None 
param_yolo_nms_thresh = None 
param_yolo_input_size = None 

last_weight = -1
weigher_denoise_thresh = 20

param_pixel_value_min_limit = None
param_pixel_open_ir_vlaue = 0
param_pixel_dark_value = 0
param_bbox_area_min_limit = 0
param_bird_binary_thr = 15
param_bird_num_thr = 5

param_capture_interval = '' 
param_save_image_interval = ''

param_last_capture_time = ''
param_last_save_image_time = ''
param_enable_thermal = ''
param_thermal_adjust = ''

def update_last_capture_time_and_write_to_file(new_capture_time):
    global param_last_capture_time, share_config
    try:
        param_last_capture_time = new_capture_time 
        write_share_config_last_capture_time(share_config, new_capture_time)
    except Exception as e:
        logger.error(str(e))

def update_last_save_image_time_and_write_to_file(new_save_image_time):
    global param_last_save_image_time, share_config
    try:
        param_last_save_image_time = new_save_image_time
        write_share_config_last_save_image_time(share_config, new_save_image_time)
    except Exception as e:
        logger.error(str(e))

def get_version():
    return version

def check_config_section():
    if not config.has_section('common'):
        config.add_section('common')

    if not config.has_section('path'):
        config.add_section('path')

    if not config.has_section('api'):
        config.add_section('api')

    if not config.has_section('gpio'):
        config.add_section('gpio')

    if not config.has_section('device'):
        config.add_section('device')

    if not config.has_section('param'):
        config.add_section('param')

    config.write(open(config_file, 'w'))

def check_config_valid():
    if device_dual_rgb and device_dual_ir:
        logger.warning('dual rgb and dual ir are on.')

def get_config():
    global version, \
        path_yolo_model_cfg, path_yolo_model_weights, path_yolo_model_names, \
        path_weigher_model_ckpt, path_bird_weight_model, path_fish_stereo_cal, \
        path_save_ai_dir, path_save_raw_dir, path_save_depth_dir, path_save_heatmap_dir, path_save_raw_right_dir, path_save_raw_left_dir,\
        path_save_weigher_dir, path_save_flir_rgb_dir, path_save_flir_raw_dir, path_save_raw_modified_dir, path_save_ndwi_dir,\
        path_iml_crop_param, api_upload_record, \
        device_dual_rgb, device_dual_ir, device_dual_starlight, device_webcam, \
        param_yolo_conf_thresh, param_yolo_nms_thresh, param_yolo_input_size, param_pixel_value_min_limit, param_pixel_open_ir_vlaue, param_pixel_dark_value, param_bbox_area_min_limit, \
        param_capture_interval, param_save_image_interval ,param_last_capture_time, param_last_save_image_time, \
        param_enable_thermal, param_thermal_adjust 

    try:
        version = config.get('common', 'version')
    except Exception as e:
        logger.warning(e)
        version = ''

    try:
        path_yolo_model_cfg = config.get('path', 'yolo_model_cfg')
    except Exception as e:
        logger.warning(e)
        path_yolo_model_cfg = ''

    try:
        path_yolo_model_weights = config.get('path', 'yolo_model_weights')
    except Exception as e:
        logger.warning(e)
        path_yolo_model_weights = ''

    try:
        path_yolo_model_names = config.get('path', 'yolo_model_names')
    except Exception as e:
        logger.warning(e)
        path_yolo_model_names = ''

    try:
        path_weigher_model_ckpt = config.get('path', 'weigher_model_weight')
    except Exception as e:
        logger.warning(e)
        path_weigher_model_ckpt = ''

    try:
        path_bird_weight_model = config.get('path', 'weight_dnn_model_ckpt')
    except Exception as e:
        logger.warning(e)
        path_bird_weight_model = ''

    try: 
        path_fish_stereo_cal = config.get('path', 'fish_stereo_cal')
    except Exception as e:
        logger.warning(e)
        path_fish_stereo_cal = ''

    try:
        path_save_ai_dir = config.get('path', 'save_ai_dir')
    except Exception as e:
        logger.warning(e)
        path_save_ai_dir = ''

    try:
        path_save_raw_dir = config.get('path', 'save_raw_dir')
    except Exception as e:
        logger.warning(e)
        path_save_raw_dir = ''

    try:
        path_save_depth_dir = config.get('path', 'save_depth_dir')
    except Exception as e:
        logger.warning(e)
        path_save_depth_dir = ''

    try:
        path_save_heatmap_dir = config.get('path', 'save_heatmap_dir')
    except Exception as e:
        logger.warning(e)
        path_save_heatmap_dir = ''

    try:
        path_save_weigher_dir = config.get('path', 'save_weigher_dir')
    except Exception as e:
        logger.warning(e)
        path_save_weigher_dir = ''

    try:
        path_save_flir_rgb_dir = config.get('path', 'save_flir_rgb_dir')
    except Exception as e:
        logger.warning(e)
        path_save_flir_rgb_dir = ''

    try:
        path_save_flir_raw_dir = config.get('path', 'save_flir_raw_dir')
    except Exception as e:
        logger.warning(e)
        path_save_flir_raw_dir = ''
    
    try:
        path_save_raw_modified_dir = config.get('path', 'save_raw_modified_dir')
    except Exception as e:
        logger.warning(e)
        path_save_raw_modified_dir = ''
        
    try:
        path_iml_crop_param = config.get('path', 'iml_crop_param')
    except Exception as e:
        logger.warning(e)
        path_iml_crop_param = ''

    try:
        path_save_raw_left_dir = config.get('path', 'save_raw_left_dir')
    except Exception as e:
        logger.warning(e)
        path_save_raw_left_dir = ''
        
    try:
        path_save_raw_right_dir = config.get('path', 'save_raw_right_dir')
    except Exception as e:
        logger.warning(e)
        path_save_raw_right_dir = ''
        
    try:
        path_save_ndwi_dir = config.get('path', 'save_ndwi_dir')
    except Exception as e:
        logger.warning(e)
        path_save_ndwi_dir = ''

    try:
        api_upload_record = config.get('api', 'upload_record')
    except Exception as e:
        logger.warning(e)
        api_upload_record = ''

    try:
        device_dual_rgb = config.getboolean('device', 'dual_rgb')
    except Exception as e:
        logger.warning(e)
        device_dual_rgb = False 

    try:
        device_dual_ir = config.getboolean('device', 'dual_ir')
    except Exception as e:
        logger.warning(e)
        device_dual_ir = False 
        
    try:
        device_dual_starlight = config.getboolean('device', 'dual_starlight')
    except Exception as e:
        logger.warning(e)
        device_dual_starlight = False 

    try:
        device_webcam = config.getboolean('device', 'webcam')
    except Exception as e:
        logger.warning(e)
        device_webcam = False 

    try:
        param_yolo_conf_thresh = float(config.get('param', 'yolo_conf_thresh'))
    except Exception as e:
        logger.warning(e)
        param_yolo_conf_thresh = None 

    try:
        param_yolo_nms_thresh = float(config.get('param', 'yolo_nms_thresh'))
    except Exception as e:
        logger.warning(e)
        param_yolo_nms_thresh = None 

    try:
        param_yolo_input_size = int(config.get('param', 'yolo_input_size'))
    except Exception as e:
        logger.warning(e)
        param_yolo_input_size = None 

    try:
        param_pixel_value_min_limit = int(config.get('param', 'pixel_value_min_limit'))
    except Exception as e:
        logger.warning(e)
        param_pixel_value_min_limit = 0 

    try:
        param_pixel_open_ir_vlaue = int(config.get('param', 'pixel_open_ir_vlaue'))
    except Exception as e:
        logger.warning(e)
        param_pixel_open_ir_vlaue = 0 

    try:
        param_pixel_dark_value = int(config.get('param', 'pixel_dark_value'))
    except Exception as e:
        logger.warning(e)
        param_pixel_dark_value = 0 

    try:
        param_bbox_area_min_limit = int(config.get('param', 'bbox_area_min_limit'))
    except Exception as e:
        logger.warning(e)
        param_bbox_area_min_limit = 0 

    try:
        param_capture_interval = int(config.get('param', 'capture_interval'))
    except Exception as e:
        logger.warning(e)
        param_capture_interval = '' 

    try:
        param_last_capture_time = share_config.get('param', 'last_capture_time')
    except Exception as e:
        logger.warning(e)
        param_last_capture_time = '' 

    try:
        param_save_image_interval = int(config.get('param', 'save_image_interval'))
    except Exception as e:
        logger.warning(e)
        param_save_image_interval = '' 

    try:
        param_last_save_image_time = share_config.get('param', 'last_save_image_time')
    except Exception as e:
        logger.warning(e)
        param_last_save_image_time = '' 
    
    try:
        param_enable_thermal = share_config.getboolean('param', 'enable_thermal')
    except Exception as e:
        param_enable_thermal = False
        
    try:
        param_thermal_adjust = int(share_config.get('param', 'thermal_adjust'))
    except Exception as e:
        param_thermal_adjust = ''
        

def reload_config():
    check_config_section()
    get_config()
    check_config_valid()
    